# Magpie Wiki

Welcome to the Magpie Wiki. Please read [Contributing](https://github.com/Blinue/Magpie/blob/main/CONTRIBUTING_EN.md) if you'd like to contribute the the documentations.

[FAQ](https://github.com/Blinue/Magpie/wiki/FAQ_EN)

[Compiling](https://github.com/Blinue/Magpie/wiki/Compiling)

[Customizing Scaling Configurations](https://github.com/Blinue/Magpie/wiki/Customizing_Scaling_Configurations)

[Customizing Effects (MagpieFX)](https://github.com/Blinue/Magpie/wiki/Customizing_Effects)

[Performance Improvements](https://github.com/Blinue/Magpie/wiki/Performance_Improvements)

[Capture Modes](https://github.com/Blinue/Magpie/wiki/Capture_Modes)
