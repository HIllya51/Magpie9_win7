# Magpie Wiki

欢迎来到 Magpie Wiki。如果你想贡献文档，请阅读[贡献指南](https://github.com/Blinue/Magpie/blob/main/CONTRIBUTING.md#%E6%88%91%E6%83%B3%E8%B4%A1%E7%8C%AE%E6%96%87%E6%A1%A3-)。

[English version](https://github.com/Blinue/Magpie/wiki/Home_EN)

[FAQ](https://github.com/Blinue/Magpie/wiki/FAQ)

[编译指南](https://github.com/Blinue/Magpie/wiki/%E7%BC%96%E8%AF%91%E6%8C%87%E5%8D%97)

[自定义缩放配置](https://github.com/Blinue/Magpie/wiki/%E8%87%AA%E5%AE%9A%E4%B9%89%E7%BC%A9%E6%94%BE%E9%85%8D%E7%BD%AE)

[自定义效果（MagpieFX）](https://github.com/Blinue/Magpie/wiki/%E8%87%AA%E5%AE%9A%E4%B9%89%E6%95%88%E6%9E%9C%EF%BC%88MagpieFX%EF%BC%89)

[性能优化建议](https://github.com/Blinue/Magpie/wiki/%E6%80%A7%E8%83%BD%E4%BC%98%E5%8C%96%E5%BB%BA%E8%AE%AE)

[捕获模式对比](https://github.com/Blinue/Magpie/wiki/捕获模式对比)
